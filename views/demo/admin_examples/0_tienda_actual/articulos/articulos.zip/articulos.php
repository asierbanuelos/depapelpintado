<!doctype html>
<!--[if lt IE 7 ]><html lang="es" class="no-js ie6"><![endif]-->
<!--[if IE 7 ]><html lang="es" class="no-js ie7"><![endif]-->
<!--[if IE 8 ]><html lang="es" class="no-js ie8"><![endif]-->
<!--[if IE 9 ]><html lang="es" class="no-js ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang="es" class="no-js"><!--<![endif]-->
<head>
	<meta charset="utf-8">
	<title>Artículos</title>
	<meta name="description" content=""/>
	<meta name="keywords" content=""/>
	<?php $this->load->view('includes/admin_head'); ?>
</head>
<body>
<?php $this->load->view('includes/admin_header'); 
$cola=array('pared'=>'Pared','papel'=>'Papel');?>
  <div class="container">
    <?=form_open('admin_library/add_art');?>
    <div class="sec row"><div class="col six t-six m-full">
    <div class="sec row"><div class="col six">GAMA:</div><div class="col six">ESTILO:</div></div>
    <div class="sec row"><?=form_multiselect('gama[]',$gama,'','class="col six" style="height:400px"')?><?=form_multiselect('estilo[]',$estilo,'','class="col six" style="height:400px"')?></div>
    </div>
    <div class="col six t-six m-full">
          <div class="sec row"><div class="col six">Fabricante:</div><?=form_dropdown('fab',$fab,'','class="six fabr"')?></div>
    <div class="sec row"><div class="col six">Colección:</div><?=form_dropdown('col',$col,'','class="six cole"')?></div>
    <div class="sec row"><div class="col six">Modelo:</div><?=form_dropdown('mod',$mod,'','class="six mod"')?></div>
    <div class="sec row"><div class="col six">Referencia:</div><?=  form_input("ref","",'class="six"')?></div>
    <div class="sec row"><div class="col six">Nombre:</div><?=  form_input("name","",'class="six"')?></div>
    <div class="sec row"><div class="col six">Lavable:</div><?= form_checkbox("lavable","1")?></div>
    <div class="sec row"><div class="col six">Resistente al Sol:</div><?= form_checkbox("sol","1")?></div>
    <div class="sec row"><div class="col six">Vinilo:</div><?= form_checkbox("vinilo","1")?></div>
    <div class="sec row"><div class="col six">Encolar a:</div><?=form_dropdown('cola',$cola,'','class="six fabr"')?></div>
    <div class="sec row"><div class="col six">Ancho metros:</div><?= form_input("ancho","",'class="six"')?></div>
    <div class="sec row"><div class="col six">Largo metros:</div><?= form_input("largo","",'class="six"')?></div>
    <div class="sec row"><div class="col six">Case metros:</div><?= form_input("case","",'class="six"')?></div>
    <div class="sec row"><div class="col six">Peso:</div><?= form_input("weight","",'class="six"')?></div>
    <div class="sec row"><div class="col six">Precio:</div><?= form_input("precio","",'class="six"')?></div>
    </div></div>
    <?=form_submit("test", "Guardar",'class="button orange-button six m-full send"')?>
    <?=form_reset("test","Resetear",'class="button orange-button six m-full"')?>
    <?=form_close();?>
  </div>
 
  <div class="container list">
   
<?
foreach ($all as $key => $value) {?>
     <div class="sec row">
      
       <div class="col one t-two m-three">
         <span style="background-color: #000;display:block;width:74px;height:74px"></span>
       </div>
       <div class="col two t-three m-three">
         <?=$value['item_name']?><br/>
         <?=$value['cat_name']?><br/>
         <?=$value['coleccion_name']?><br/>
         <?=$value['modelo_name']?><br/>

       </div>
       <div class="col two t-three m-three">
         Ancho:<?=$value['item_ancho']?><br/>
         Largo:<?=$value['item_largo']?><br/>
         Case: <?=$value['item_case']?><br/>
         <?=($value['item_lavable']==1)?"L":"l"?> - <?=($value['item_sol']==1)?"S":"s"?> - <?=($value['item_vinilo']==1)?"V":"v"?>
       </div>
      
       <div class="col two t-three m-three">
         <b>Precio: <?=$value['item_price']?></b><br/>
         <span class="del" id="<?=$value['item_id']?>">Del</span>
       </div>
       
       
     </div>
<?}?>
   </div>
  <?php $this->load->view('includes/scripts'); ?> 
  <script>
    function addline(d){
      var l=(d.item_lavable==1)?"L":"l";
      var s=(d.item_sol==1)?"S":"s";
      var v=(d.item_vinilo==1)?"V":"v";
      var text='<div class="sec row"><div class="col one t-two m-three"><span style="background-color: #000;display:block;width:74px;height:74px"></span></div><div class="col two t-three m-three">'+
         d.item_name+'<br/>'+d.cat_name+'<br/>'+d.coleccion_name+'<br/>'+d.modelo_name+'<br/></div><div class="col two t-three m-three">Ancho: '+d.item_ancho+'<br/>Largo: '+d.item_largo+'<br/>Case: '+d.item_case+'<br/>'+
         l+' - '+s+' - '+v+'</div><div class="col two t-three m-three"><b>Precio: '+
          d.item_price+'</b><br/></div></div>';
       $('.list').prepend(text);
      
    }
  $('.send').click(function(event)
	{
		event.preventDefault();
        var parent_form = $(this).closest('form');
        var submit_url = parent_form.attr('action');
		var $form_inputs = parent_form.find(':input');
		var form_data = {};
		$form_inputs.each(function()
		{
			form_data[this.name] = $(this).val();
		});
		$.ajax(
		{
			url: submit_url,
			type: 'POST',
			data: parent_form.serialize(),
			success:function(data)
			{
				addline($.parseJSON(data)[0]);
			}
		});
	});
    $(".fabr").change(function(e){
    if($(this).val()>0){
      $.ajax({
        url:"<?=site_url('admin_library/get_col_select')?>",
        type:'POST',
        data:$(this).closest('form').serialize(),
        success:function(data){ $('.cole').html(data);$('.mod').html("");}
      })}
    });
    $(".cole").change(function(e){
      if($(this).val()>0){
      $.ajax({
        url:"<?=site_url('admin_library/get_mod_select')?>",
        type:'POST',
        data:$(this).closest('form').serialize(),
        success:function(data){ $('.mod').html(data);}
      })}
    });
    $('.del').click(function(e){
    var t=$(this).attr('id');
    var p=$(this).parent().parent();
      $.ajax({
        url:"<?=site_url('admin_library/del')?>",
        type:'POST',
        data:'&t=items&n=item&i='+t,
        success:function(data){p.slideUp();}
      })
    });
    $(".fabr").change();
    
</script>
</body>
</html>