<!doctype html>
<!--[if lt IE 7 ]><html lang="es" class="no-js ie6"><![endif]-->
<!--[if IE 7 ]><html lang="es" class="no-js ie7"><![endif]-->
<!--[if IE 8 ]><html lang="es" class="no-js ie8"><![endif]-->
<!--[if IE 9 ]><html lang="es" class="no-js ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang="es" class="no-js"><!--<![endif]-->
<head>
	<meta charset="utf-8">
	<title>Estilos</title>
	<meta name="description" content=""/>
	<meta name="keywords" content=""/>
	<?php $this->load->view('includes/admin_head'); ?>
</head>
<body>
  <?php $this->load->view('includes/admin_header'); ?>
  <div class="container">
    <?=form_open('admin_library/add_estilo');?>
    <div class="sec row"><div class="col two t-six m-six">ESTILO:</div><?=  form_input("name","",'class="two t-six m-six"')?>
    <?=form_submit("test", "Guardar",'class="button orange-button t-full m-full send"')?></div>
    <?=form_close();?>
  </div>
  <div class="container list">  
<?foreach ($estilos as $key => $value) {?>
     <div class="sec row">
       <div class="col one">
         <?=$key?>
       </div>
       <div class="col ten">
         <?=$value?>
       </div>
       <div id="<?=$key?>" class="col one del">
         Del
       </div>
     </div>
<?}?>
  </div>
    <?php $this->load->view('includes/scripts'); ?> 
  <script>
    function addline(d){
      var text='<div class="sec row"><div class="col one">'+d.estilo_id+'</div><div class="col ten">'+d.estilo_name+
              '</div><div id="'+d.estilo_id+'" class="col one del">Del</div></div>';
       $('.list').prepend(text);
      
    }
  $('.send').click(function(event){
		event.preventDefault();
		var parent_form = $(this).closest('form');
		var submit_url = parent_form.attr('action');
		var $form_inputs = parent_form.find(':input');
		var form_data = {};
		$form_inputs.each(function()
		{
			form_data[this.name] = $(this).val();
		});

		$.ajax(
		{
			url: submit_url,
			type: 'POST',
			data: form_data,
			success:function(data)
			{
				addline(jQuery.parseJSON(data)[0]);
			}
		});
	});
    $('.del').click(function(e){
    var t=$(this).attr('id');
    var p=$(this).parent();
      $.ajax({
        url:"<?=site_url('admin_library/del')?>",
        type:'POST',
        data:'&t=estilo&n=estilo&i='+t,
        success:function(data){p.slideUp();}
      })
    });
</script>

</body>
</html>